interface RisoSketchProps {
  variant?: number;
}

export function RisoSketch({ variant = 1 }: RisoSketchProps) {
  // Risograph colors - vibrant and fluorescent
  const risoColors = {
    fluorescentPink: '#FF48C4',
    fluorescentBlue: '#00A0E9',
    fluorescentYellow: '#FEE440',
    fluorescentOrange: '#FF6D00',
    fluorescentGreen: '#00F5B5',
    red: '#FF0050',
    violet: '#8B00FF',
  };

  const sketches = [
    // Sketch 1: Abstract circles and lines
    <svg key="sketch1" className="absolute inset-0 w-full h-full pointer-events-none mix-blend-multiply opacity-60" viewBox="0 0 400 300" xmlns="http://www.w3.org/2000/svg">
      {/* Spiral sketch */}
      <path
        d="M 50 50 Q 60 30, 80 35 T 120 50 T 150 80 T 160 120"
        stroke={risoColors.fluorescentPink}
        strokeWidth="3"
        fill="none"
        strokeLinecap="round"
      />
      {/* Circle sketch */}
      <circle
        cx="320"
        cy="80"
        r="40"
        stroke={risoColors.fluorescentBlue}
        strokeWidth="4"
        fill="none"
        strokeDasharray="5,5"
      />
      {/* Scribble line */}
      <path
        d="M 200 250 Q 220 240, 230 255 T 260 250 T 280 260 T 310 255"
        stroke={risoColors.fluorescentYellow}
        strokeWidth="5"
        fill="none"
        strokeLinecap="round"
      />
      {/* Abstract shape */}
      <path
        d="M 80 200 L 100 220 L 85 240 L 110 250 L 95 265"
        stroke={risoColors.fluorescentOrange}
        strokeWidth="3"
        fill="none"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      {/* Dots cluster */}
      <circle cx="340" cy="240" r="4" fill={risoColors.fluorescentGreen} />
      <circle cx="350" cy="245" r="5" fill={risoColors.fluorescentGreen} />
      <circle cx="360" cy="235" r="3" fill={risoColors.fluorescentGreen} />
    </svg>,

    // Sketch 2: Wavy lines and stars
    <svg key="sketch2" className="absolute inset-0 w-full h-full pointer-events-none mix-blend-multiply opacity-60" viewBox="0 0 400 300" xmlns="http://www.w3.org/2000/svg">
      {/* Wavy line top */}
      <path
        d="M 10 60 Q 40 40, 70 60 T 130 60 T 190 60 T 250 60"
        stroke={risoColors.fluorescentBlue}
        strokeWidth="4"
        fill="none"
        strokeLinecap="round"
      />
      {/* Star sketch */}
      <path
        d="M 350 50 L 360 70 L 380 75 L 365 90 L 370 110 L 350 100 L 330 110 L 335 90 L 320 75 L 340 70 Z"
        stroke={risoColors.red}
        strokeWidth="2"
        fill="none"
      />
      {/* Squiggle */}
      <path
        d="M 50 250 Q 70 230, 90 250 T 130 250 T 170 250"
        stroke={risoColors.fluorescentYellow}
        strokeWidth="5"
        fill="none"
        strokeLinecap="round"
      />
      {/* Rectangle sketch */}
      <rect
        x="280"
        y="200"
        width="60"
        height="50"
        stroke={risoColors.violet}
        strokeWidth="3"
        fill="none"
        transform="rotate(-10 310 225)"
      />
      {/* Curved line */}
      <path
        d="M 150 120 Q 180 100, 200 130 Q 220 160, 250 140"
        stroke={risoColors.fluorescentPink}
        strokeWidth="3"
        fill="none"
      />
    </svg>,

    // Sketch 3: Geometric and organic mix
    <svg key="sketch3" className="absolute inset-0 w-full h-full pointer-events-none mix-blend-multiply opacity-60" viewBox="0 0 400 300" xmlns="http://www.w3.org/2000/svg">
      {/* Triangle sketch */}
      <path
        d="M 60 80 L 90 40 L 120 80 Z"
        stroke={risoColors.fluorescentOrange}
        strokeWidth="4"
        fill="none"
        strokeLinejoin="round"
      />
      {/* Spiral circle */}
      <path
        d="M 320 200 Q 330 180, 350 190 Q 370 200, 360 220 Q 350 240, 330 230 Q 310 220, 320 200"
        stroke={risoColors.fluorescentGreen}
        strokeWidth="3"
        fill="none"
      />
      {/* Cross hatch lines */}
      <path
        d="M 200 50 L 250 100"
        stroke={risoColors.fluorescentBlue}
        strokeWidth="2"
        fill="none"
      />
      <path
        d="M 250 50 L 200 100"
        stroke={risoColors.fluorescentBlue}
        strokeWidth="2"
        fill="none"
      />
      {/* Organic blob */}
      <path
        d="M 100 200 Q 120 190, 140 200 Q 150 220, 130 235 Q 110 240, 95 225 Q 85 210, 100 200"
        stroke={risoColors.fluorescentPink}
        strokeWidth="4"
        fill="none"
      />
      {/* Zigzag */}
      <path
        d="M 280 120 L 300 100 L 320 120 L 340 100 L 360 120"
        stroke={risoColors.fluorescentYellow}
        strokeWidth="3"
        fill="none"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>,

    // Sketch 4: Doodle style
    <svg key="sketch4" className="absolute inset-0 w-full h-full pointer-events-none mix-blend-multiply opacity-60" viewBox="0 0 400 300" xmlns="http://www.w3.org/2000/svg">
      {/* Cloud doodle */}
      <path
        d="M 60 100 Q 50 90, 60 80 Q 70 70, 85 80 Q 95 75, 105 85 Q 110 95, 100 105 Q 80 110, 60 100"
        stroke={risoColors.fluorescentBlue}
        strokeWidth="3"
        fill="none"
      />
      {/* Arrow */}
      <path
        d="M 250 180 L 320 180 M 310 170 L 320 180 L 310 190"
        stroke={risoColors.red}
        strokeWidth="4"
        fill="none"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      {/* Scribble circle */}
      <ellipse
        cx="180"
        cy="100"
        rx="35"
        ry="40"
        stroke={risoColors.fluorescentYellow}
        strokeWidth="3"
        fill="none"
        transform="rotate(20 180 100)"
      />
      {/* Dots trail */}
      <circle cx="50" cy="250" r="5" fill={risoColors.fluorescentPink} />
      <circle cx="70" cy="245" r="4" fill={risoColors.fluorescentPink} />
      <circle cx="85" cy="250" r="6" fill={risoColors.fluorescentPink} />
      <circle cx="105" cy="248" r="4" fill={risoColors.fluorescentPink} />
      {/* Abstract line */}
      <path
        d="M 300 50 Q 320 70, 310 90 Q 300 110, 320 125"
        stroke={risoColors.fluorescentGreen}
        strokeWidth="4"
        fill="none"
        strokeLinecap="round"
      />
    </svg>,

    // Sketch 5: Bold strokes
    <svg key="sketch5" className="absolute inset-0 w-full h-full pointer-events-none mix-blend-multiply opacity-60" viewBox="0 0 400 300" xmlns="http://www.w3.org/2000/svg">
      {/* Bold curved stroke */}
      <path
        d="M 30 150 Q 100 100, 170 150 T 310 150"
        stroke={risoColors.violet}
        strokeWidth="6"
        fill="none"
        strokeLinecap="round"
      />
      {/* Circle cluster */}
      <circle cx="80" cy="60" r="25" stroke={risoColors.fluorescentOrange} strokeWidth="3" fill="none" />
      <circle cx="95" cy="75" r="15" stroke={risoColors.fluorescentOrange} strokeWidth="3" fill="none" />
      {/* X mark */}
      <path
        d="M 320 200 L 360 240 M 360 200 L 320 240"
        stroke={risoColors.fluorescentYellow}
        strokeWidth="5"
        fill="none"
        strokeLinecap="round"
      />
      {/* Underline squiggle */}
      <path
        d="M 150 250 Q 170 240, 190 250 Q 210 260, 230 250 Q 250 240, 270 250"
        stroke={risoColors.fluorescentBlue}
        strokeWidth="4"
        fill="none"
        strokeLinecap="round"
      />
    </svg>,

    // Sketch 6: Minimal and elegant
    <svg key="sketch6" className="absolute inset-0 w-full h-full pointer-events-none mix-blend-multiply opacity-60" viewBox="0 0 400 300" xmlns="http://www.w3.org/2000/svg">
      {/* Curved bracket */}
      <path
        d="M 100 80 Q 60 120, 100 160"
        stroke={risoColors.fluorescentPink}
        strokeWidth="4"
        fill="none"
        strokeLinecap="round"
      />
      {/* Asterisk */}
      <path
        d="M 320 100 L 320 140 M 300 110 L 340 130 M 340 110 L 300 130"
        stroke={risoColors.fluorescentGreen}
        strokeWidth="3"
        fill="none"
        strokeLinecap="round"
      />
      {/* Gentle wave */}
      <path
        d="M 50 240 Q 100 220, 150 240 Q 200 260, 250 240"
        stroke={risoColors.fluorescentYellow}
        strokeWidth="5"
        fill="none"
        strokeLinecap="round"
      />
      {/* Corner accent */}
      <path
        d="M 360 60 L 360 40 L 380 40"
        stroke={risoColors.fluorescentBlue}
        strokeWidth="4"
        fill="none"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      {/* Dots */}
      <circle cx="200" cy="120" r="6" fill={risoColors.red} />
      <circle cx="220" cy="115" r="4" fill={risoColors.red} />
    </svg>,

    // Sketch 7: Playful mix
    <svg key="sketch7" className="absolute inset-0 w-full h-full pointer-events-none mix-blend-multiply opacity-60" viewBox="0 0 400 300" xmlns="http://www.w3.org/2000/svg">
      {/* Heart sketch */}
      <path
        d="M 70 100 Q 70 80, 85 80 Q 100 80, 100 100 Q 100 80, 115 80 Q 130 80, 130 100 Q 130 130, 100 150 Q 70 130, 70 100"
        stroke={risoColors.red}
        strokeWidth="3"
        fill="none"
      />
      {/* Spring coil */}
      <path
        d="M 250 60 Q 260 50, 270 60 Q 280 70, 270 80 Q 260 90, 270 100 Q 280 110, 270 120"
        stroke={risoColors.fluorescentBlue}
        strokeWidth="3"
        fill="none"
        strokeLinecap="round"
      />
      {/* Plus signs */}
      <path d="M 340 200 L 340 230 M 325 215 L 355 215" stroke={risoColors.fluorescentYellow} strokeWidth="4" fill="none" strokeLinecap="round" />
      {/* Curly bracket */}
      <path
        d="M 180 200 Q 160 200, 160 220 Q 160 240, 180 240"
        stroke={risoColors.fluorescentPink}
        strokeWidth="3"
        fill="none"
        strokeLinecap="round"
      />
    </svg>,

    // Sketch 8: Coffee themed
    <svg key="sketch8" className="absolute inset-0 w-full h-full pointer-events-none mix-blend-multiply opacity-60" viewBox="0 0 400 300" xmlns="http://www.w3.org/2000/svg">
      {/* Coffee cup sketch */}
      <path
        d="M 80 120 L 80 160 Q 80 170, 90 170 L 130 170 Q 140 170, 140 160 L 140 120 M 60 120 L 160 120"
        stroke={risoColors.fluorescentOrange}
        strokeWidth="3"
        fill="none"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      {/* Steam lines */}
      <path d="M 95 100 Q 90 85, 95 70" stroke={risoColors.fluorescentBlue} strokeWidth="2" fill="none" />
      <path d="M 110 100 Q 115 85, 110 70" stroke={risoColors.fluorescentBlue} strokeWidth="2" fill="none" />
      <path d="M 125 100 Q 120 85, 125 70" stroke={risoColors.fluorescentBlue} strokeWidth="2" fill="none" />
      {/* Bean shapes */}
      <ellipse cx="300" cy="100" rx="12" ry="20" stroke={risoColors.violet} strokeWidth="2" fill="none" />
      <path d="M 300 85 Q 305 100, 300 115" stroke={risoColors.violet} strokeWidth="2" fill="none" />
      {/* Sparkles */}
      <path d="M 350 50 L 350 65 M 343 57.5 L 357 57.5" stroke={risoColors.fluorescentYellow} strokeWidth="2" fill="none" strokeLinecap="round" />
      <path d="M 250 220 L 250 235 M 243 227.5 L 257 227.5" stroke={risoColors.fluorescentPink} strokeWidth="2" fill="none" strokeLinecap="round" />
    </svg>,
  ];

  return sketches[variant % sketches.length];
}
