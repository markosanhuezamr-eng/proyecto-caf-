import { useState } from "react";
import { ArrowUpRight, Clock, RotateCw } from "lucide-react";
import { ImageWithFallback } from "./figma/ImageWithFallback";

interface CoffeeCardProps {
  name: string;
  description: string;
  imageUrl: string;
  prepTime: string;
  steps: string[];
  onClick: () => void;
}

export function CoffeeCard({
  name,
  description,
  imageUrl,
  prepTime,
  steps,
  onClick,
}: CoffeeCardProps) {
  const [isFlipped, setIsFlipped] = useState(false);

  return (
    <article
      className="group relative h-[510px] [perspective:1400px]"
      onMouseLeave={() => setIsFlipped(false)}
    >
      <div
        className={`relative size-full transition-transform duration-700 ease-[cubic-bezier(.2,.75,.25,1)] [transform-style:preserve-3d] group-hover:[transform:rotateY(180deg)] ${
          isFlipped ? "[transform:rotateY(180deg)]" : ""
        }`}
      >
        <div className="absolute inset-0 overflow-hidden rounded-[2rem] border border-white/70 bg-white/45 p-2 shadow-[0_20px_70px_-30px_rgba(34,52,29,.35)] backdrop-blur-2xl [backface-visibility:hidden]">
          <div className="relative h-[64%] overflow-hidden rounded-[1.6rem] bg-[#dcebb6]">
            <ImageWithFallback
              src={imageUrl}
              alt={`Preparación de ${name}`}
              className="size-full object-cover transition-transform duration-700 group-hover:scale-[1.04]"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-[#182218]/60 via-transparent to-white/10" />
            <div className="absolute left-4 top-4 rounded-full border border-white/50 bg-white/25 px-3 py-1.5 text-[11px] font-semibold uppercase tracking-[0.18em] text-white backdrop-blur-xl">
              Guía de barra
            </div>
            <div className="absolute bottom-4 left-4 flex items-center gap-2 rounded-full border border-white/35 bg-[#172016]/35 px-3 py-2 text-xs text-white backdrop-blur-xl">
              <Clock className="size-3.5" />
              {prepTime}
            </div>
          </div>

          <div className="flex h-[36%] flex-col justify-between px-4 pb-4 pt-5">
            <div>
              <h3 className="font-display text-[2rem] leading-none tracking-[-0.04em] text-[#172016]">
                {name}
              </h3>
              <p className="mt-3 line-clamp-2 text-sm leading-6 text-[#51604d]">
                {description}
              </p>
            </div>
            <button
              type="button"
              onClick={() => setIsFlipped(true)}
              className="flex items-center gap-2 self-start text-xs font-semibold uppercase tracking-[0.16em] text-[#33402d] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#789b42]"
              aria-label={`Ver preparación rápida de ${name}`}
            >
              <RotateCw className="size-4" />
              Pasa para preparar
            </button>
          </div>
        </div>

        <div className="absolute inset-0 flex flex-col overflow-hidden rounded-[2rem] border border-white/70 bg-[linear-gradient(145deg,rgba(245,255,213,.92),rgba(255,240,143,.82))] p-7 shadow-[0_24px_80px_-28px_rgba(34,52,29,.45)] backdrop-blur-2xl [backface-visibility:hidden] [transform:rotateY(180deg)]">
          <div className="flex items-start justify-between gap-4">
            <div>
              <p className="text-[10px] font-bold uppercase tracking-[0.22em] text-[#66774f]">
                Preparación rápida
              </p>
              <h3 className="font-display mt-2 text-3xl leading-none tracking-[-0.04em] text-[#172016]">
                {name}
              </h3>
            </div>
            <span className="flex size-11 shrink-0 items-center justify-center rounded-full border border-[#172016]/10 bg-white/45">
              <Clock className="size-4 text-[#3f4e36]" />
            </span>
          </div>

          <ol className="mt-7 flex-1 space-y-4">
            {steps.slice(0, 4).map((step, index) => (
              <li key={step} className="flex gap-3">
                <span className="flex size-6 shrink-0 items-center justify-center rounded-full bg-[#172016] text-[10px] font-bold text-[#efffae]">
                  {String(index + 1).padStart(2, "0")}
                </span>
                <p className="line-clamp-2 text-[13px] leading-5 text-[#35412f]">
                  {step}
                </p>
              </li>
            ))}
          </ol>

          <button
            type="button"
            onClick={onClick}
            className="mt-5 flex w-full items-center justify-between rounded-full bg-[#172016] px-5 py-3.5 text-sm font-semibold text-white transition hover:bg-[#2d3c27] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#172016] focus-visible:ring-offset-2"
          >
            Ver receta completa
            <ArrowUpRight className="size-4" />
          </button>
        </div>
      </div>
    </article>
  );
}
