import { X, Clock, Printer, Share2 } from "lucide-react";
import { ImageWithFallback } from "./figma/ImageWithFallback";

interface CoffeeModalProps {
  isOpen: boolean;
  onClose: () => void;
  coffee: {
    name: string;
    description: string;
    imageUrl: string;
    prepTime: string;
    steps: string[];
    tips: string[];
  } | null;
}

export function CoffeeModal({ isOpen, onClose, coffee }: CoffeeModalProps) {
  if (!isOpen || !coffee) return null;

  return (
    <div
      className="fixed inset-0 z-50 overflow-y-auto bg-[#10170f]/55 p-4 backdrop-blur-xl transition-all"
      onClick={onClose}
    >
      <div className="min-h-screen flex items-center justify-center py-12">
        <div
          className="relative w-full max-w-5xl overflow-hidden rounded-[2.5rem] border border-white/40 bg-[#f7faec]/80 shadow-[0_40px_120px_-30px_rgba(0,0,0,.65)] backdrop-blur-2xl transition-all"
          onClick={(e) => e.stopPropagation()}
        >
          <div className="absolute right-10 top-10 -z-0 size-20 rounded-full bg-[#d9f477]/30 blur-xl" />
          <div className="absolute bottom-20 left-10 -z-0 size-20 rotate-45 rounded-3xl bg-[#ffe47c]/30 blur-lg" />

          <button
            onClick={onClose}
            className="absolute right-5 top-5 z-10 rounded-full border border-white/50 bg-white/35 p-3 text-white shadow-lg backdrop-blur-xl transition-all hover:rotate-90 hover:bg-white/55"
            aria-label="Cerrar receta"
          >
            <X className="size-5" />
          </button>

          <div className="relative aspect-[16/8] w-full overflow-hidden">
            <ImageWithFallback
              src={coffee.imageUrl}
              alt={coffee.name}
              className="size-full object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-[#10170f]/80 via-[#10170f]/5 to-transparent" />
            <div className="absolute bottom-0 left-0 p-8 text-white md:p-12">
              <p className="mb-3 text-[10px] font-bold uppercase tracking-[0.24em] text-[#e5f990]">Receta de barra</p>
              <h1 className="font-display text-5xl tracking-[-0.04em] drop-shadow-md md:text-7xl">
                {coffee.name}
              </h1>
            </div>
          </div>

          <div className="relative p-8 md:p-12">
            <div className="mb-8 border-b border-[#263320]/10 pb-7">
              <p className="max-w-3xl text-lg leading-relaxed text-[#53604e]">
                {coffee.description}
              </p>
            </div>

            <div className="mb-12 flex flex-wrap items-center gap-6 rounded-2xl border border-white/70 bg-white/35 p-4 backdrop-blur-xl">
              <div className="flex items-center gap-2">
                <span className="flex size-10 items-center justify-center rounded-full bg-[#e5f79a]">
                  <Clock className="size-4 text-[#40502f]" />
                </span>
                <div>
                  <p className="text-[10px] font-bold uppercase tracking-[0.16em] text-[#74806d]">Tiempo de preparación</p>
                  <p className="font-semibold text-[#172016]">{coffee.prepTime}</p>
                </div>
              </div>
              <div className="ml-auto flex items-center gap-3">
                <button 
                  className="rounded-full p-3 text-[#66715f] transition-colors hover:bg-[#e5f79a] hover:text-[#26351f]"
                  title="Imprimir receta"
                >
                  <Printer className="size-5" />
                </button>
                <button 
                  className="rounded-full p-3 text-[#66715f] transition-colors hover:bg-[#ffe786] hover:text-[#3d3517]"
                  title="Compartir"
                >
                  <Share2 className="size-5" />
                </button>
              </div>
            </div>

            <div className="mb-10">
              <h2 className="font-display mb-8 text-4xl tracking-[-0.04em] text-[#172016]">
                Paso a paso
              </h2>
              <ol className="grid gap-x-10 gap-y-7 md:grid-cols-2">
                {coffee.steps.map((step, index) => (
                  <li key={index} className="group flex gap-4">
                    <div className="flex size-8 flex-shrink-0 items-center justify-center rounded-full bg-[#172016] text-[11px] font-bold text-[#e5f990] transition-transform group-hover:scale-110">
                      {String(index + 1).padStart(2, "0")}
                    </div>
                    <p className="flex-1 pt-1 text-sm leading-6 text-[#46513f]">
                      {step}
                    </p>
                  </li>
                ))}
              </ol>
            </div>

            {coffee.tips.length > 0 && (
              <div className="relative overflow-hidden rounded-[2rem] border border-white/70 bg-[linear-gradient(135deg,rgba(228,247,144,.55),rgba(255,230,124,.4))] p-8 backdrop-blur-xl">
                <div className="absolute -bottom-12 -right-10 size-40 rounded-full bg-white/30 blur-xl" />
                <h3 className="font-display relative z-10 mb-5 text-3xl tracking-[-0.03em] text-[#172016]">
                  Consejos del Barista
                </h3>
                <ul className="relative z-10 grid gap-3 md:grid-cols-2">
                  {coffee.tips.map((tip, index) => (
                    <li key={index} className="flex gap-3 text-[#43503c]">
                      <span className="mt-2.5 size-1.5 flex-shrink-0 rounded-full bg-[#668536]" />
                      <span className="text-sm italic leading-6">{tip}</span>
                    </li>
                  ))}
                </ul>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
