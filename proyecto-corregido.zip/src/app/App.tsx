import { useState } from "react";
import { CoffeeCard } from "./components/CoffeeCard";
import { CoffeeModal } from "./components/CoffeeModal";
import { Search, Coffee, ArrowDown, Sparkles } from "lucide-react";

interface CoffeeType {
  name: string;
  description: string;
  imageUrl: string;
  prepTime: string;
  steps: string[];
  tips: string[];
}

const coffeeData: CoffeeType[] = [
  {
    name: "Espresso",
    description: "La base fundamental de todas las bebidas de café. Intenso, rico y complejo.",
    imageUrl: "https://images.unsplash.com/photo-1729277133095-bff46b56c29a?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxiYXJpc3RhJTIwbWFraW5nJTIwZXNwcmVzc28lMjBjbG9zZSUyMHVwJTIwbWluaW1hbGlzdHxlbnwxfHx8fDE3NzIwNDc5Mjh8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    prepTime: "25-30 segundos",
    steps: [
      "Calienta la máquina de espresso y la taza durante 15-20 minutos hasta alcanzar la temperatura óptima de 90-95°C.",
      "Muele 18-20 gramos de café fresco justo antes de preparar. El molido debe ser fino y uniforme, similar a la sal de mesa.",
      "Distribuye el café uniformemente en el portafiltro y nivela con el dedo para evitar canales.",
      "Presiona el café con 15-20 kg de presión usando el tamper, asegurando una superficie completamente plana.",
      "Limpia los bordes del portafiltro y colócalo en el grupo de la máquina inmediatamente.",
      "Inicia la extracción y cronometra. El espresso debe empezar a fluir después de 3-5 segundos.",
      "Extrae 40ml en 25-30 segundos. El flujo debe ser constante, como miel cayendo.",
      "Detén la extracción cuando el café comience a salir rubio claro. Debe haber una crema dorada de 3-4mm."
    ],
    tips: [
      "Usa café recién tostado de 7-21 días para mejor sabor.",
      "La crema debe ser color avellana con manchas 'tigre'.",
      "Si sale muy rápido, muele más fino. Si sale lento, más grueso.",
      "El agua debe estar entre 90-96°C para una extracción óptima."
    ]
  },
  {
    name: "Cappuccino",
    description: "Equilibrio perfecto de espresso, leche y espuma. Un clásico italiano.",
    imageUrl: "https://images.unsplash.com/photo-1687902625864-faedb40f83a8?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjYXBwdWNjaW5vJTIwbGF0dGUlMjBhcnQlMjBtaW5pbWFsaXN0JTIwd2hpdGUlMjBiYWNrZ3JvdW5kfGVufDF8fHx8MTc3MjA0NzkyOXww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    prepTime: "3-4 minutos",
    steps: [
      "Prepara un espresso doble (40-50ml) siguiendo la técnica tradicional en una taza de 150-180ml precalentada.",
      "Vierte 120ml de leche fría (4-7°C) en una jarra de acero inoxidable hasta llenar 1/3 del recipiente.",
      "Purga la varilla de vapor para eliminar agua condensada.",
      "Sumerge la punta de la varilla justo bajo la superficie de la leche en un ángulo de 15 grados.",
      "Abre el vapor completamente. Escucharás un sonido de 'papel rasgándose' mientras incorporas aire durante 5-7 segundos.",
      "Baja la jarra ligeramente para sumergir más la varilla y crear un vórtex. Continúa vaporizando hasta alcanzar 60-65°C.",
      "Cierra el vapor y retira la jarra. La leche debe tener una textura de pintura brillante, sin burbujas grandes.",
      "Golpea suavemente la jarra contra el mostrador y gira para eliminar burbujas. La espuma debe ser microespuma sedosa.",
      "Vierte la leche sobre el espresso desde una altura de 3-4cm, comenzando en el centro.",
      "Cuando la taza esté 2/3 llena, baja la jarra y acelera el vertido para crear el arte latte."
    ],
    tips: [
      "La proporción ideal es 1/3 espresso, 1/3 leche, 1/3 espuma.",
      "La leche debe estar fría antes de vaporizar.",
      "La textura debe ser brillante y sin burbujas visibles.",
      "La temperatura perfecta es 60-65°C, nunca exceder 70°C."
    ]
  },
  {
    name: "Latte Macchiato",
    description: "Capas elegantes de leche manchada con café. Suave y visualmente atractivo.",
    imageUrl: "https://images.unsplash.com/photo-1604298458655-ae6e04213678?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxsYXR0ZSUyMG1hY2NoaWF0byUyMGxheWVyZWQlMjBnbGFzcyUyMG1pbmltYWxpc3R8ZW58MXx8fHwxNzcyMDQ3OTI5fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    prepTime: "4-5 minutos",
    steps: [
      "Vaporiza 200ml de leche siguiendo la técnica de microespuma hasta alcanzar 60-65°C.",
      "Vierte la leche vaporizada en un vaso de vidrio alto (300ml) llenándolo completamente.",
      "Deja reposar la leche durante 30-60 segundos para que se separen las capas naturalmente.",
      "Prepara un espresso simple o doble (30-40ml) en un recipiente aparte.",
      "Con una cuchara, sostén ligeramente la espuma de la superficie.",
      "Vierte lentamente el espresso en el centro del vaso desde una altura de 10cm.",
      "El café debe atravesar la espuma y asentarse en la leche creando 3 capas distintivas.",
      "La capa inferior será leche, la media café, y la superior espuma manchada."
    ],
    tips: [
      "Usar vaso transparente para apreciar las capas.",
      "Verter el espresso lentamente para mejores capas.",
      "La temperatura de la leche afecta la separación de capas.",
      "Dejar reposar es clave para la estratificación perfecta."
    ]
  },
  {
    name: "Americano",
    description: "Espresso alargado con agua caliente. Suave pero con el carácter del espresso.",
    imageUrl: "https://images.unsplash.com/photo-1658418467495-134ce7d69430?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxhbWVyaWNhbm8lMjBjb2ZmZWUlMjBibGFjayUyMGN1cCUyMG1pbmltYWxpc3R8ZW58MXx8fHwxNzcyMDQ3OTI5fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    prepTime: "2-3 minutos",
    steps: [
      "Calienta agua fresca filtrada hasta alcanzar 85-90°C. No debe hervir para evitar sabor amargo.",
      "Precalienta una taza grande de 240-350ml con agua caliente.",
      "Prepara un espresso doble (40-50ml) directamente en la taza precalentada.",
      "Vierte suavemente 150-200ml de agua caliente sobre el espresso en movimiento circular.",
      "Para preservar la crema, algunos baristas vierten primero el agua y luego el espresso encima.",
      "La proporción recomendada es 1:2 (espresso:agua) pero ajusta según preferencia.",
      "Remueve suavemente si deseas una mezcla uniforme."
    ],
    tips: [
      "Usa agua filtrada para mejor sabor.",
      "No uses agua hirviendo, quema el café.",
      "Ajusta la cantidad de agua según tu gusto.",
      "Algunos prefieren 'Long Black': agua primero, espresso después."
    ]
  },
  {
    name: "Mocha",
    description: "Deliciosa fusión de café, chocolate y leche. Un postre hecho bebida.",
    imageUrl: "https://images.unsplash.com/photo-1630445035074-2b3d21673229?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtb2NoYSUyMGNvZmZlZSUyMGNob2NvbGF0ZSUyMG1pbmltYWxpc3R8ZW58MXx8fHwxNzcyMDQ3OTI5fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    prepTime: "4-5 minutos",
    steps: [
      "Agrega 2 cucharadas (30ml) de jarabe de chocolate o 15g de cacao en polvo a una taza grande precalentada.",
      "Si usas cacao en polvo, mezcla con un poco de agua caliente hasta crear una pasta suave sin grumos.",
      "Prepara un espresso doble (40-50ml) y viértelo sobre el chocolate.",
      "Remueve vigorosamente con una cuchara hasta que el chocolate esté completamente disuelto.",
      "Vaporiza 180ml de leche hasta alcanzar 65°C con microespuma cremosa.",
      "Vierte la leche sobre la mezcla de café y chocolate, creando capas.",
      "Agrega crema batida en la parte superior formando una cúpula generosa.",
      "Decora con cacao en polvo, chocolate rallado o jarabe de chocolate en la crema."
    ],
    tips: [
      "Usa chocolate de buena calidad para mejor sabor.",
      "Puedes usar chocolate blanco para una variante.",
      "Ajusta la cantidad de chocolate según tu gusto.",
      "La crema batida es opcional pero tradicional."
    ]
  },
  {
    name: "Flat White",
    description: "Microespuma sedosa con espresso doble intenso. Origen australiano/neozelandés.",
    imageUrl: "https://images.unsplash.com/photo-1719840195557-b87e064766e4?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmbGF0JTIwd2hpdGUlMjBjb2ZmZWUlMjBsYXR0ZSUyMGFydCUyMGNlcmFtaWMlMjBjdXAlMjBtaW5pbWFsaXN0fGVufDF8fHx8MTc3MjA0NzkyOXww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    prepTime: "3-4 minutos",
    steps: [
      "Prepara un espresso doble ristretto (30-35ml) en una taza de 150-180ml. Debe ser más concentrado que un espresso normal.",
      "Vierte 100ml de leche entera fría en una jarra de metal pequeña.",
      "Vaporiza la leche creando microespuma muy fina. La textura debe ser como pintura de seda líquida.",
      "Calienta la leche hasta 60-62°C, más baja que un latte. Esto crea una textura más sedosa.",
      "Golpea la jarra y gira para integrar completamente la espuma con la leche.",
      "Vierte la leche desde cerca del espresso (2-3cm) con movimiento constante.",
      "La microespuma debe ser tan fina que apenas se note la capa de espuma, solo 2-3mm.",
      "Termina con arte latte si deseas, la textura perfecta lo permite."
    ],
    tips: [
      "La clave es la microespuma ultra fina, sin burbujas.",
      "Usa taza más pequeña que un latte para mantener sabor fuerte.",
      "El ristretto aporta intensidad sin amargor.",
      "Menos espuma que cappuccino, más cremosidad."
    ]
  },
  {
    name: "Cortado",
    description: "Espresso 'cortado' con leche, perfectamente equilibrado 1:1.",
    imageUrl: "https://images.unsplash.com/photo-1630659508320-b1627db88a9c?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjb3J0YWRvJTIwZ2xhc3MlMjBjb2ZmZWUlMjBtaW5pbWFsaXN0fGVufDF8fHx8MTc3MjA0NzkyOXww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    prepTime: "2-3 minutos",
    steps: [
      "Calienta un vaso pequeño de vidrio de 120-150ml o una tacita de cerámica.",
      "Prepara un espresso doble (40ml) directamente en el vaso.",
      "Vaporiza 40ml de leche entera. La proporción debe ser 1:1 con el espresso.",
      "Calienta la leche solo hasta 55-60°C para mantenerla dulce y no quemar.",
      "Crea una microespuma ligera, menos densa que para un cappuccino.",
      "Vierte la leche caliente sobre el espresso en el centro.",
      "La leche debe 'cortar' la acidez del espresso, de ahí su nombre.",
      "No debe haber casi espuma en la superficie, solo una capa muy fina."
    ],
    tips: [
      "Perfecto para después de las comidas.",
      "La proporción 1:1 es sagrada en el cortado.",
      "Se sirve en vaso pequeño de vidrio tradicionalmente.",
      "La leche debe ser menos espumosa que en otras bebidas."
    ]
  },
  {
    name: "Affogato",
    description: "Helado bañado en espresso caliente. El postre italiano definitivo.",
    imageUrl: "https://images.unsplash.com/photo-1595259601830-ff9f67f0239e?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxhZmZvZ2F0byUyMGNvZmZlZSUyMGljZSUyMGNyZWFtJTIwcG91cmluZyUyMGVzcHJlc3NvJTIwbWluaW1hbGlzdHxlbnwxfHx8fDE3NzIwNDc5Mjl8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    prepTime: "1-2 minutos",
    steps: [
      "Enfría una copa de vidrio, taza ancha o bowl en el congelador durante 10 minutos.",
      "Saca el helado de vainilla de alta calidad del congelador 2 minutos antes para que se ablande ligeramente.",
      "Coloca 1-2 bolas generosas de helado de vainilla en el recipiente frío.",
      "Prepara un espresso simple o doble (30-40ml) inmediatamente.",
      "Vierte el espresso caliente directamente sobre el helado en el momento de servir.",
      "El contraste de temperatura debe ser dramático: helado muy frío y café muy caliente.",
      "Sirve inmediatamente con una cucharita larga.",
      "Opcional: decora con chocolate rallado, almendras o un biscotti al lado."
    ],
    tips: [
      "La calidad del helado es crucial, usa uno cremoso artesanal.",
      "El espresso debe estar recién hecho y muy caliente.",
      "Come rápido antes de que se derrita completamente.",
      "Puedes añadir un licor como amaretto para versión adulta."
    ]
  },
];

export default function App() {
  const [selectedCoffee, setSelectedCoffee] = useState<CoffeeType | null>(null);
  const [searchQuery, setSearchQuery] = useState("");

  const filteredCoffee = coffeeData.filter((coffee) =>
    coffee.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    coffee.description.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="relative min-h-screen overflow-hidden bg-background font-sans text-foreground selection:bg-[#d8f56b] selection:text-[#172016]">
      <div className="pointer-events-none fixed -left-36 -top-24 size-[34rem] rounded-full bg-[#d9f477]/45 blur-[90px]" />
      <div className="pointer-events-none fixed -right-32 top-[30%] size-[30rem] rounded-full bg-[#ffe378]/45 blur-[100px]" />

      <header className="sticky top-0 z-30 px-4 pt-4">
        <div className="mx-auto flex max-w-7xl items-center justify-between rounded-full border border-white/70 bg-white/45 px-4 py-3 shadow-[0_10px_40px_-24px_rgba(28,42,24,.5)] backdrop-blur-2xl md:px-6">
          <button
            type="button"
            className="flex items-center gap-3"
            onClick={() => setSearchQuery("")}
          >
            <span className="flex size-9 items-center justify-center rounded-full bg-[#182218] text-[#e9ff9b]">
              <Coffee className="size-4" />
            </span>
            <span className="font-display text-xl tracking-[-0.04em] text-[#172016]">
              Taza / Estudio
            </span>
          </button>
          <div className="hidden items-center gap-7 text-xs font-semibold uppercase tracking-[0.14em] text-[#53604c] md:flex">
            <a href="#recetas" className="transition hover:text-[#172016]">Recetas</a>
            <span className="size-1 rounded-full bg-[#9bb84f]" />
            <span>Manual doméstico · 2026</span>
          </div>
        </div>
      </header>

      <section className="relative mx-auto grid min-h-[620px] max-w-7xl items-center gap-10 px-6 py-20 md:grid-cols-[1.15fr_.85fr] md:px-8 md:py-24">
        <div className="relative z-10">
          <div className="mb-7 inline-flex items-center gap-2 rounded-full border border-white/80 bg-white/35 px-3 py-2 text-[11px] font-bold uppercase tracking-[0.18em] text-[#4c5c42] backdrop-blur-xl">
            <Sparkles className="size-3.5" />
            Café bien hecho, sin misterio
          </div>
          <h1 className="font-display max-w-3xl text-[clamp(4rem,9vw,8.5rem)] leading-[.82] tracking-[-0.065em] text-[#172016]">
            Prepara.<br />
            <span className="italic text-[#6f8e3d]">Prueba.</span><br />
            Repite.
          </h1>
          <div className="mt-10 flex max-w-xl flex-col gap-7 border-l border-[#172016]/20 pl-6 sm:flex-row sm:items-end sm:justify-between">
            <p className="max-w-sm text-base leading-7 text-[#52604d]">
              Una guía visual para dominar ocho clásicos de cafetería con técnica, tiempo y un poco de paciencia.
            </p>
            <a
              href="#recetas"
              className="flex size-12 shrink-0 items-center justify-center rounded-full bg-[#172016] text-white transition hover:translate-y-1"
              aria-label="Ir a las recetas"
            >
              <ArrowDown className="size-5" />
            </a>
          </div>
        </div>

        <div className="relative mx-auto w-full max-w-[430px]">
          <div className="absolute -left-12 top-10 size-28 rounded-full border border-white/80 bg-[#e4f98f]/60 backdrop-blur-xl" />
          <div className="absolute -right-10 bottom-16 size-24 rotate-12 rounded-[2rem] border border-white/70 bg-[#ffe785]/70 backdrop-blur-xl" />
          <div className="relative rotate-2 overflow-hidden rounded-[3rem] border-[10px] border-white/45 bg-white/30 p-1 shadow-[0_35px_100px_-35px_rgba(35,54,29,.45)] backdrop-blur-2xl">
            <img
              src="https://images.unsplash.com/photo-1511081692775-05d0f180a065?w=900&h=1100&fit=crop&auto=format"
              alt="Barista vertiendo leche sobre un café"
              className="aspect-[4/5] w-full rounded-[2.35rem] object-cover"
            />
          </div>
          <div className="absolute -bottom-5 -left-8 rounded-2xl border border-white/80 bg-white/55 px-5 py-4 shadow-xl backdrop-blur-2xl">
            <p className="text-[10px] font-bold uppercase tracking-[0.2em] text-[#6e7a67]">Lección 01</p>
            <p className="font-display mt-1 text-2xl text-[#172016]">Textura primero.</p>
          </div>
        </div>
      </section>

      <main id="recetas" className="relative mx-auto max-w-7xl px-6 pb-24 pt-12 md:px-8 md:pt-20">
        <div className="mb-12 grid gap-7 md:grid-cols-[1fr_auto] md:items-end">
          <div>
            <p className="mb-3 text-[11px] font-bold uppercase tracking-[0.2em] text-[#71805f]">El recetario</p>
            <h2 className="font-display text-5xl tracking-[-0.05em] text-[#172016] md:text-7xl">
              Elige tu próxima taza
            </h2>
          </div>
          <label className="relative block w-full md:w-[360px]">
            <span className="sr-only">Buscar una receta</span>
            <Search className="absolute left-5 top-1/2 size-4 -translate-y-1/2 text-[#66735e]" />
            <input
              type="search"
              placeholder="Buscar espresso, latte..."
              value={searchQuery}
              onChange={(event) => setSearchQuery(event.target.value)}
              className="w-full rounded-full border border-white/80 bg-white/50 py-4 pl-12 pr-5 text-sm text-[#172016] shadow-[0_10px_35px_-24px_rgba(28,42,24,.45)] outline-none backdrop-blur-xl transition placeholder:text-[#7f897a] focus:border-[#8ba74f] focus:ring-4 focus:ring-[#d9ef8b]/40"
            />
          </label>
        </div>

        {filteredCoffee.length > 0 ? (
          <div className="grid gap-7 sm:grid-cols-2 lg:grid-cols-3">
            {filteredCoffee.map((coffee, index) => (
              <CoffeeCard
                key={index}
                name={coffee.name}
                description={coffee.description}
                imageUrl={coffee.imageUrl}
                prepTime={coffee.prepTime}
                steps={coffee.steps}
                onClick={() => setSelectedCoffee(coffee)}
              />
            ))}
          </div>
        ) : (
          <div className="flex flex-col items-center justify-center rounded-[2rem] border border-white/70 bg-white/35 py-24 text-center backdrop-blur-xl">
            <div className="mb-4 rounded-full bg-[#edf8bd] p-6">
              <Search className="size-8 text-[#5a684f]" />
            </div>
            <h3 className="font-display text-3xl text-[#172016]">No encontramos esa receta</h3>
            <p className="mt-2 text-[#687362]">
              Intenta buscar otro tipo de café o ingrediente.
            </p>
            <button 
              onClick={() => setSearchQuery("")}
              className="mt-6 rounded-full bg-[#172016] px-6 py-3 text-sm font-semibold text-white transition hover:bg-[#31402b]"
            >
              Ver todas las recetas
            </button>
          </div>
        )}
      </main>

      <footer className="px-4 pb-4">
        <div className="mx-auto flex max-w-7xl flex-col gap-5 rounded-[2rem] bg-[#172016] px-7 py-8 text-white md:flex-row md:items-center md:justify-between">
          <div className="flex items-center gap-3">
            <Coffee className="size-5 text-[#dff779]" />
            <span className="font-display text-2xl">Taza / Estudio</span>
          </div>
          <p className="text-xs uppercase tracking-[0.16em] text-white/55">
            Hecho despacio · Servido caliente
          </p>
        </div>
      </footer>
      <CoffeeModal
        isOpen={selectedCoffee !== null}
        onClose={() => setSelectedCoffee(null)}
        coffee={selectedCoffee}
      />
    </div>
  );
}
